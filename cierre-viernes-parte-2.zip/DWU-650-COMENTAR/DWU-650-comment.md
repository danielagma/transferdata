### **QA Update: AC 2 PASSED ✅, AC 1, 3, 4 and 5 PENDING**
* **Environment:** UAT2
* **Trades under test:** TOMS manual tickets 21031192 (Settlement Location ST, no Short Note 1) and 21031193 (Settlement Location EU, no Short Note 1)

---
### AC 2. SettlementLocationAbbreviation is no longer used - **PASSED ✅**
21031192 arrives with SettlementLocationAbbreviation ST and 21031193 with EU, both without Short Note 1. Both are published with Settlement.SettlementLocation null, and STP Hub acknowledges them.

Evidence: 1-192-TradeEvent-ST.png, 2-192-payload-SettlementLocation-null.png, 3-192-ack.png, 4-193-TradeEvent-EU.png, 5-193-payload-SettlementLocation-null.png, 6-193-ack.png

---
**Pending:**
* AC 1 and AC 3: TOMS ticket with Short Note 1 populated. Requested to Sergio.
* AC 5: amend and cancel of that ticket with Short Note 1. Requested to Sergio.
* AC 4: a trade from another source, read after this change.
