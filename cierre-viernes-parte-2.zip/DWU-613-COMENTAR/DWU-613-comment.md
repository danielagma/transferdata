### **QA Update: Change 1 and Change 2 PASSED ✅, Change 3 PENDING**
* **Environment:** UAT2
* **Trades under test:** TOMS manual tickets 21031189 (Short Note 6 PNT), 21031192 (no salesperson), 21031186 (Short Note 6 N.A.); TOMS internal pair 21031187 (main) / 21031188 (mirror)

---
### Change 1. Sales.SalesBook from SalespersonName - **PASSED ✅**
21031189 arrives with SalespersonName ETABOADE and is published with SalesBook ETABOADE. 21031192 arrives without SalespersonName and is published with SalesBook empty.

Evidence: 1-189-TradeEvent-Salesperson-SN6-PNT.png, 2-189-payload.png, 3-192-TradeEvent-sin-Salesperson.png, 4-192-payload-SalesBook-vacio.png

### Change 2. InternalTradeType defaults to Main - **PASSED ✅**
21031186 and the internal main 21031187 are published with InternalTradeType Main. The mirror 21031188 is not published: Trade Service logs StpHubEventPublishingSkipped with Reason "The trade is an internal mirror".

Evidence: 6-186-payload-TradeSrc-vacio-Main.png, 7-187-payload-Main.png, 8-188-mirror-skipped.png

### Change 3. TradeSrc from Short Note 6
21031186 arrives with Short Note 6 N.A. and is published with TradeSrc empty, as expected.
21031189 (TransactionType MT) arrives with Short Note 6 PNT and is published with TradeSrc "PNT", not "Voice".

Evidence: 5-186-TradeEvent-SN6-NA.png, 6-186-payload-TradeSrc-vacio-Main.png, 1-189-TradeEvent-Salesperson-SN6-PNT.png, 2-189-payload.png

---
**Pending:**
* Change 3: Short Note 6 PNT on a TT ticket. Requested to Sergio.

@Fation Gjoni, is an MT ticket in scope for Change 3, or should the PNT rule be checked only on TT tickets?
