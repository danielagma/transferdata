### **QA Update: AC 2 on Bloomberg PASSED ✅**
* **Environment:** UAT2
* **Trades under test:** Bloomberg outright 6212:20261008:1:5 (8 Oct, GB00BNNGP668, counterparty MIAL, product class GILTS)

---
### AC 2. CalculateSalesCredit on Bloomberg - **PASSED ✅**
The TRADE is published at 12:47:30.186 UTC with Counterparty.Glcs MIAL, Instrument.Class GILTS and Counterparty.CalculateSalesCredit true. STP Hub acknowledges it at 12:47:30.383 UTC.

Evidence: 01-bbg-6212-1-5-payloaddocument-mial-calculatesalescredit-true.png, 02-bbg-6212-1-5-ack.png

---
**Pending:**
* AC 6: D2D trade.
* AC 7: confirmation from the STP Hub schema (question of 12 Oct).
