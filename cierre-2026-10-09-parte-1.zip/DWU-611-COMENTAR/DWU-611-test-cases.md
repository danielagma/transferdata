# DWU-611 · Test cases

Fuente: [`stories/DWU-611.md`](../../stories/DWU-611.md), tabla "Acceptance Criteria (Testing Table)" del ticket (Fation), capturada el 2026-10-07. Cada escenario lleva `# Covers AC n`. La evidencia de UAT2 está en `deliverables/evidencia/2026-10-08-trades.md` y `deliverables/evidencia/2026-10-09-trades.md`.

## Test cases

```gherkin
Feature: IsInternalTrade for trades generated from venue RFQs (DWU-611)
  As the STP Hub
  I need Darwin to send PostTradeEvent.Trade.IsInternalTrade from the counterparty static data
  So that internal trades executed on a venue are flagged correctly

  Background:
    Given the environment is UAT2
    And the static screen is STATIC > TRADE REFERENCE DATA > Counterparty, field "Is Internal"

  # Covers AC 1, AC 5
  Scenario: Venue RFQ trade against a counterparty with Is Internal on
    Given counterparty "TELE" has "Is Internal" set to On
    When a Tradeweb RFQ trade is executed against "TELE"
    Then the StpHubPayloadDocument contains "Counterparty.Glcs" equal to "TELE"
    And the payload contains "IsInternalTrade" equal to true
    And STP Hub acknowledges the payload

  # Covers AC 4
  Scenario: Venue RFQ trade against a counterparty with Is Internal off
    Given counterparty "<glcs>" has "Is Internal" set to Off
    When a Tradeweb RFQ trade is executed against "<glcs>"
    Then the payload contains "IsInternalTrade" equal to false
    And STP Hub acknowledges the payload

  # Covers AC 2
  Scenario: TOMS amend of a venue RFQ trade
    Given a Tradeweb RFQ trade executed against counterparty "<glcs>"
    And the trade is amended in TOMS with the venue transaction id populated
    When the amend is published to STP Hub
    Then the Amend payload contains "IsInternalTrade" equal to the "Is Internal" flag of "<glcs>" in static data
    And STP Hub acknowledges the Amend

  # Covers AC 3
  Scenario: TOMS cancel of a venue RFQ trade
    Given a Tradeweb RFQ trade executed against counterparty "<glcs>"
    And the trade is cancelled in TOMS with the venue transaction id populated
    When the cancel is published to STP Hub
    Then the Cancel payload contains "IsInternalTrade" equal to the "Is Internal" flag of "<glcs>" in static data
    And STP Hub acknowledges the Cancel

  # Covers AC 6
  Scenario: TOMS manual entry trade does not use the counterparty static flag
    Given counterparty "TELE" has "Is Internal" set to On
    When a manual TOMS ticket is booked against "TELE" between a client and a trading book
    Then the payload contains "Counterparty.Glcs" equal to "TELE"
    And the payload contains "IsInternalTrade" equal to false
    And STP Hub acknowledges the payload
```

## Resultado en UAT2

| AC | Trade | Resultado | Evidencia |
|---|---|---|---|
| 1, 5 | Tradeweb `20261008.SAN3.EUGV.50`, TELE On | `IsInternalTrade true`, ACK | `Trades\2026-10-08\01-tw-50-internal-dwu-611\` |
| 4 | Tradeweb `20261008.SAN3.EUGV.170`, BSTE Off | `false` | `Trades\2026-10-09\02-tw-170-amend-toms-21030728\` (03), `04-static-BSTE-is-internal-off\` |
| 2 | Amend TOMS `21030723` de `20261008.SAN3.EUGV.171`, BSTE Off | `false`, ACK | `Trades\2026-10-09\01-tw-171-amend-toms-21030723\`, `04-static-BSTE-is-internal-off\` |
| 3 | Cancel TOMS `21030575` de `20261008.SAN3.EUGV.177`, BSTE Off | `false`, ACK | `Trades\2026-10-09\03-tw-177-cancel-toms-21030575\`, `04-static-BSTE-is-internal-off\` |
| 6 | TOMS manual `21031186` contra TELE (On) | `false`, ACK | `Trades\2026-10-09\05-toms-21031186-broker-shortselling\` |
