### **QA Update: AC 1 to 6 PASSED ✅, AC 2 and AC 3 PENDING for a counterparty with Is Internal On**
* **Environment:** UAT2
* **Trades under test:** Tradeweb 20261008.SAN3.EUGV.50 (TELE); TOMS amend 21030723 of 20261008.SAN3.EUGV.171 and TOMS cancel 21030575 of 20261008.SAN3.EUGV.177 (BSTE); TOMS manual ticket 21031186 (TELE); Tradeweb 20261008.SAN3.EUGV.170 (BSTE)

---
### AC 1 and AC 5. Venue trade, Is Internal On - **PASSED ✅**
TELE has Is Internal On. 20261008.SAN3.EUGV.50 is published with Glcs TELE and IsInternalTrade true, and STP Hub acknowledges it.

Evidence: 1-static-TELE-IsInternal-on.png, 2-TW50-payload.png, 3-TW50-ack.png

### AC 2. Amend of a venue trade - **PASSED ✅**
BSTE has Is Internal Off. The TOMS amend 21030723 of 20261008.SAN3.EUGV.171 is published with Glcs BSTE and IsInternalTrade false, and STP Hub acknowledges it.

Evidence: 4-static-BSTE-IsInternal-off.png, 5-TW171-amend-payload.png, 6-TW171-amend-ack.png

### AC 3. Cancel of a venue trade - **PASSED ✅**
The TOMS cancel 21030575 of 20261008.SAN3.EUGV.177 is published with Glcs BSTE and IsInternalTrade false, and STP Hub acknowledges it.

Evidence: 4-static-BSTE-IsInternal-off.png, 7-TW177-cancel-payload.png, 8-TW177-cancel-ack.png

### AC 4. Is Internal Off - **PASSED ✅**
BSTE has Is Internal Off. The Tradeweb RFQ trade 20261008.SAN3.EUGV.170 against BSTE is published as New with Glcs BSTE and IsInternalTrade false.

Evidence: 4-static-BSTE-IsInternal-off.png, 11-TW170-New-payload.png

### AC 6. TOMS manual entry - **PASSED ✅**
The manual TOMS ticket 21031186 against TELE (Is Internal On) is published with Glcs TELE and IsInternalTrade false: the counterparty flag is not applied. STP Hub acknowledges it.

Evidence: 1-static-TELE-IsInternal-on.png, 9-TOMS186-payload.png, 10-TOMS186-ack.png

---
**Pending:**
* AC 2 and AC 3: TOMS amend and cancel of a venue trade against a counterparty with Is Internal On (expected IsInternalTrade true).
