### **QA Update: scenario 1 amend and scenario 2 amend and cancel PASSED ✅, scenario 1 cancel PENDING**
* **Environment:** UAT2
* **Trades under test:** manual TOMS ticket 21030399 (booked 2026-10-07), amended on 2026-10-08 as ticket 21030717; TOMS amend 21030723 of Tradeweb 20261008.SAN3.EUGV.171; TOMS cancel 21030575 of Tradeweb 20261008.SAN3.EUGV.177

---
### Scenario 1. Manual TOMS ticket, amend - **PASSED ✅**
The amend 21030717 is published as Amend with SourceId 21030717 (the amendment ticket, not the original 21030399), PreviousTradeId 21030399, MessageId 21030717:DWBZoFcLNdFqee:Amend:ab220f8bbed3fdd2. STP Hub acknowledges it at 12:17:26.888 UTC, no error.

Evidence: 1-717-amend-TradeEvent.png, 2-717-amend-payload.png, 3-717-amend-ack.png

### Scenario 2. TOMS events with Long Note 2, amend - **PASSED ✅**
TOMS sends the amend 21030723 with Long Note 2 Tradeweb:20261008.SAN3.EUGV.171. The amend is published with SourceId Tradeweb:20261008.SAN3.EUGV.171 (the Long Note 2, not the ticket 21030723) and TomsTicketId 21030723. STP Hub acknowledges it.

Evidence: 4-723-amend-TradeEvent-LongNote2.png, 5-723-amend-payload.png, 6-723-amend-ack.png

### Scenario 2. TOMS events with Long Note 2, cancel - **PASSED ✅**
TOMS sends the cancel 21030575 with Long Note 2 Tradeweb:20261008.SAN3.EUGV.177. The cancel is published with SourceId Tradeweb:20261008.SAN3.EUGV.177 (the Long Note 2, not the ticket 21030575) and TomsTicketId 21030575. STP Hub acknowledges it.

Evidence: 7-575-cancel-TradeEvent-LongNote2.png, 8-575-cancel-payload.png, 9-575-cancel-ack.png

---
**Pending:**
* Scenario 1: cancel of a manual TOMS ticket.
