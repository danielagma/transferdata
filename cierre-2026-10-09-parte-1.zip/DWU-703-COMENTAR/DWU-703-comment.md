### **QA Update: AC 2 and AC 4 PASSED ✅, AC 3 pending, AC 1, 5 and 6 development scope**
* **Environment:** UAT2
* **Trade under test:** Tradeweb switch 20261006.SAN3.EUGV.SWAP.380, legs .380 and .381, each allocated to Test 1 (80,000) and Test 2 (20,000)

---
### AC 2. Different EventIds give different allocation MessageIds - **PASSED ✅**
Leg .380: MessageId TradewebEUGV$20261006.SAN3.EUGV.380:allocation:1045. Leg .381: MessageId ...381:allocation:1046. Both acknowledged by STP Hub.

Evidence: 1-380-alloc-sent-1045.png, 2-380-alloc-ack.png, 3-381-alloc-sent-1046.png, 4-381-alloc-ack.png

### AC 4. The allocation MessageId reaches the gateway unchanged - **PASSED ✅**
The gateway's StpHubPayloadSent carries MessageId TradewebEUGV$20261006.SAN3.EUGV.380:allocation:1045 and TradewebEUGV$20261006.SAN3.EUGV.381:allocation:1046: the allocation:{EventId} format set in Trade Service, not a GUID.

Evidence: same as AC 2.

---
**Development scope:** AC 1 (retry) and AC 5 (gateway collision) cannot be triggered from a trade in UAT2. AC 6 states they are covered by the unit tests and by the Trade Service component test.

**Pending:** AC 3 (released-trade replacement). It needs the Allocation Reporting or Calypso Flow flag on, which is not available in the UAT2 screen.

@Murat Guney can you set the Calypso Flow flag on TELE / GILTS in UAT2 so we can test AC 3?
