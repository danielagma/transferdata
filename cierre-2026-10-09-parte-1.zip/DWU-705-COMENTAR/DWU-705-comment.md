### **QA Update: requirements 1 to 4 PASSED ✅, requirement 5 PENDING**
* **Environment:** UAT2
* **Trades under test:** Bloomberg RFQ 6212:20261008:1:5; Tradeweb RFQ 20261008.SAN3.EUGV.170 amended in TOMS (ticket 21030728); Tradeweb RFQ 20261008.SAN3.EUGV.177 cancelled in TOMS (ticket 21030575)

---
### Requirements 1 and 2. RFQ trade - **PASSED ✅**
Bloomberg 6212:20261008:1:5 is published as New with SourceName Bloomberg and SourceOriginalName Bloomberg_BSGI, and STP Hub acknowledges it. Tradeweb 20261008.SAN3.EUGV.170 is published as New with SourceName Tradeweb and SourceOriginalName Tradeweb_EUGV.

Evidence: 1-BBG-1-5-payload.png, 2-BBG-1-5-ack.png, 3-TW170-New-payload.png

### Requirements 3 and 4. Amend in TOMS - **PASSED ✅**
The TOMS amend 21030728 of 20261008.SAN3.EUGV.170 is published as Amend with SourceName BBG_TOMS and SourceOriginalName Tradeweb_EUGV, the same value as the New. STP Hub acknowledges it.

Evidence: 3-TW170-New-payload.png, 4-TW170-amend-payload.png, 5-TW170-amend-ack.png

### Requirements 3 and 4. Cancel in TOMS - **PASSED ✅**
20261008.SAN3.EUGV.177 is published as New with SourceOriginalName Tradeweb_EUGV. The TOMS cancel 21030575 is published as Cancel with SourceName BBG_TOMS and SourceOriginalName Tradeweb_EUGV. STP Hub acknowledges it.

Evidence: 6-TW177-New-payload.png, 7-TW177-cancel-payload.png, 8-TW177-cancel-ack.png

### Requirement 5. All RFQ venues - **PENDING**
Bloomberg and Tradeweb follow the same logic (requirements 1 to 4 above). BondVision (expected Mts_<BrokerCode>) is not verified yet.
