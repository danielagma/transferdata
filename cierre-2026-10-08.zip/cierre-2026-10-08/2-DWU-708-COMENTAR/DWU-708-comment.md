### **QA Update: amend PASSED ✅, cancel pending**
* **Environment:** UAT2
* **Trades under test:** manual TOMS ticket 21030399 (New, booked 2026-10-07), amended on 2026-10-08 as ticket 21030717

---
### Scenario 1, Amend - **PASSED ✅**
The New 21030399 was published on 2026-10-07 with SourceId 21030399. The amend 21030717 arrives at 12:17:21.470 UTC and is published as Amend at 12:17:26.670 UTC with SourceId 21030717, TradeNo 21030717, TomsTicketId 21030717, PreviousTradeId 21030399 and MessageId 21030717:DWBZoFcLNdFqee:Amend:ab220f8bbed3fdd2. STP Hub acknowledges it at 12:17:26.888 UTC.

Evidence: 1-399-New-StpHubPayloadSent.png, 2-717-amend-TradeEvent.png, 3-717-amend-StpHubPayloadSent.png, 4-717-amend-payload.png, 5-717-amend-ack.png

---
**Pending:** the Cancel row of scenario 1 (SourceId C). A cancel of 21030399 is requested.
