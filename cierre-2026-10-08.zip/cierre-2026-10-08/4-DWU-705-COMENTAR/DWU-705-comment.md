### **QA Update: requirements 1, 2 and 5 PASSED ✅, requirements 3 and 4 blocked**
* **Environment:** UAT2
* **Trades under test:** Bloomberg 6212:20261008:1:5, 6212:20261008:2:5, 6212:20261008:5:5 and Tradeweb 20261008.SAN3.EUGV.50

---
### 1. Bloomberg RFQ trades - **PASSED ✅**
The three trades are published as New with SourceName Bloomberg and SourceOriginalName Bloomberg_BSGI, and STP Hub acknowledges them. Example: 6212:20261008:1:5 at 12:47:30.186 UTC, MessageId 6212:20261008:1:5:DWBZoFkxMzd41Q:New:5a8249eb568a3c8b.

Evidence: 1-BBG-1-5-payload.png, 2-BBG-1-5-ack.png, 3-BBG-2-5-payload.png, 4-BBG-2-5-ack.png, 5-BBG-5-5-payload.png, 6-BBG-5-5-ack.png

### 2. Tradeweb RFQ trade - **PASSED ✅**
20261008.SAN3.EUGV.50 is published as New with SourceName Tradeweb and SourceOriginalName Tradeweb_EUGV, and STP Hub acknowledges it.

Evidence: 7-TW50-payload.png, 8-TW50-ack.png

---
**Blocked:** requirements 3 and 4 (SourceName BBG_TOMS and SourceOriginalName unchanged on amend and cancel). The TOMS amends of these venue trades are not published because the TVTIC is empty: 21030736 (amend of 6212:20261008:1:5) and 21030712 (amend of 20261008.SAN3.EUGV.155) have no StpHubPayloadSent.

Evidence: 9-736-amend-BBG-1-5-Sent-no-results.png, 10-712-amend-TW155-Sent-no-results.png
