### **QA Update: AC 1 PASSED ✅**
* **Environment:** UAT2
* **Trade under test:** Tradeweb outright 20261008.SAN3.EUGV.50 (SPGB 5.150 10/28, ES00000124C5, Sell 100,000), counterparty TELE

TELE has Is Internal On in Counterparty static data. The trade is published as New at 16:41:16.217 UTC with Counterparty Glcs TELE and IsInternalTrade true, MessageId 20261008.SAN3.EUGV.50:DWBZoGpmC9CN60:New:d0a42c4b87f41bf1, and STP Hub acknowledges it.

Evidence: 1-static-TELE-IsInternal-on.png, 2-TW50-TradeEvent.png, 3-TW50-payload-IsInternalTrade-true.png, 4-TW50-ack.png

AC 4 (flag false) was verified on 20261002.SAN3.EUGV.272 and 20261007.SAN3.EUGV.86.

**Blocked:** AC 2 and AC 3 (amend and cancel of an RFQ trade). TOMS amends of venue trades are not published today because the TVTIC is empty (21030736 of Bloomberg 6212:20261008:1:5, 21030712 of Tradeweb 20261008.SAN3.EUGV.155).
