### **QA Update: butterfly with Darwin Calc'n OFF - PASSED ✅**
* **Environment:** UAT2
* **Trade under test:** Tradeweb butterfly 20261008.SAN3.EUGV.BFLY.53, legs 20261008.SAN3.EUGV.54 / .55 / .56, counterparty TELE, product class GILTS

Darwin Calc'n set to No on the TELE and GILTS row of Counterparty Relationship. The three legs are published with CalculateSalesCredit false and are acknowledged by STP Hub. Darwin Calc'n was set back to Yes after the trade.

Evidence: 1-static-TELE-GILTS-Calcn-No.png, 2-leg54-payload.png, 3-leg54-ack.png, 4-leg55-payload.png, 5-leg55-ack.png, 6-leg56-payload.png, 7-leg56-ack.png

Tradeweb is now covered for outright, switch and butterfly, with the flag ON and OFF. AC 6 (D2D) stays blocked and AC 7 (JSON schema) still needs confirmation.
