### **QA Update: scenarios 1 and 2 PASSED ✅, scenarios 3 and 5 pending**
* **Environment:** UAT2
* **Trades under test:** TOMS internal pairs 21030768 (main) / 21030769 (mirror), 21030770 / 21030771, 21030774 / 21030775. Amends 21030788 (main) / 21030791 (mirror).

---
### 1. Internal trade, new (TT) - **PASSED ✅**
The mirror ticket 21030769 arrives with SecondHalfTdr2TdrTrade Y. The main ticket 21030768 is published as New (MessageId 21030768:DWBZoGGkUlYH4a:New:3b6922529bef8b6f, 14:38:42.920 UTC) with InternalTradeType Main and IsInternalTrade true, and STP Hub acknowledges it. The mirror has no StpHubPayloadSent. Same result on 21030770 / 21030771 and on mirror 21030775.

Evidence: 1-769-mirror-TradeEvent-SecondHalf-Y.png, 2-768-main-StpHubPayloadSent.png, 3-768-main-payload-Main.png, 4-768-main-ack.png, 5-769-mirror-Sent-no-results.png, 6-770-main-StpHubPayloadSent.png, 7-770-main-ack.png, 8-771-mirror-Sent-no-results.png, 9-775-mirror-Sent-no-results.png

### 2. Amend of the internal trade (CTT) - **PASSED ✅**
TOMS sends SecondHalfTdr2TdrTrade Y on the mirror's amend: ticket 21030791, TransactionType CTT, TransactionNumberOfOriginTrans 21030769 (TradeEvent at 14:48:04.211 UTC). The main amend 21030788 is published as Amend and acknowledged. The mirror amend 21030791 has no StpHubPayloadSent.

Evidence: 10-791-mirror-amend-TradeEvent-SecondHalf-Y.png, 11-788-main-amend-payload.png, 12-788-main-amend-ack.png, 13-791-mirror-amend-Sent-no-results.png

---
**Pending:** scenario 3 (cancel of the internal trade) and scenario 5 (outbound replay). Scenario 4 (futures) not run.
