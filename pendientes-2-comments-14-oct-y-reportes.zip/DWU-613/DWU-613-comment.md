### **QA Update: Change 1 and Change 2 PASSED ✅, Change 3 question open**
* **Environment:** UAT2
* **Trades under test:** TOMS tickets 21031189 (Short Note 6 PNT), 21031192 (no salesperson), 21031186 (Short Note 6 N.A.); TOMS internal pair 21031187 (main) / 21031188 (mirror); TOMS ticket 21028974, amended as 21028977 and then cancelled

---
### Change 1. Sales.SalesBook from SalespersonName - **PASSED ✅**
21031189 arrives with SalespersonName ETABOADE and is published with SalesBook ETABOADE. 21031192 arrives without SalespersonName and is published with SalesBook empty.

Evidence: 1. 189 TradeEvent Salesperson SN6 PNT.png, 2. 189 payload.png, 3. 192 TradeEvent sin Salesperson.png, 4. 192 payload SalesBook vacio.png

### Change 2. InternalTradeType defaults to Main on every TOMS event - **PASSED ✅**
New: 21031186 and the internal main 21031187 are published with InternalTradeType Main. The mirror 21031188 is not published: Trade Service logs StpHubEventPublishingSkipped with Reason "The trade is an internal mirror".
Amend and Cancel: the Amend and Cancel payloads of 21028977 are published with InternalTradeType Main.

Evidence: 6. 186 payload TradeSrc vacio Main.png, 7. 187 payload Main.png, 8. 188 mirror skipped.png, 9. 977 payload Amend Main.png, 10. 977 payload Cancel Main.png

### Change 3. TradeSrc from Short Note 6
21031186 arrives with Short Note 6 N.A. and is published with TradeSrc empty, as Change 3 says ("otherwise empty").
21031189 arrives with Short Note 6 PNT and is published with TradeSrc "PNT".

Evidence: 5. 186 TradeEvent SN6 NA.png, 6. 186 payload TradeSrc vacio Main.png, 1. 189 TradeEvent Salesperson SN6 PNT.png, 2. 189 payload.png

---
@Fation Gjoni, Change 3 says: "If that field contains "PNT" value then TradeSrc field should be mapped as "Voice", otherwise empty." TOMS ticket 21031189 has Short Note 6 PNT and is published with TradeSrc "PNT". Is "PNT" expected here, or should it be "Voice"?
