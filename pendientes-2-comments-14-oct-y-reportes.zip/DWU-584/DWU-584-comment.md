### **QA Update: AC 1, 2, 4, 5 and 14 PASSED ✅, AC 3, 6, 7, 8 and 9 PENDING, AC 10 to 13 development scope**
* **Environment:** UAT2
* **Trades under test:** TOMS internal ticket 21031187 (CustomerAccountCounterparty GBPASECM); TOMS manual ticket 21031186 (CustomerAccountCounterparty TELE); TOMS amend 21030788 of the internal ticket 21030768; Tradeweb allocation of 20261006.SAN3.EUGV.380

---
### AC 1 and AC 4. New trade, counterparty matches an active trading book - **PASSED ✅**
TOMS sends 21031187 with CustomerAccountCounterparty GBPASECM, the trading book of its mirror ticket 21031188. The trade is published as New with IsInternalTrade true, and STP Hub acknowledges it.

Evidence: 1. 187 TradeEvent GBPASECM.png, 8. 188 TradeEvent TradingBook GBPASECM.png, 2. 187 payload IsInternalTrade true.png, 3. 187 ack.png

### AC 2 and AC 4. New trade, counterparty does not match a trading book - **PASSED ✅**
TOMS sends 21031186 with CustomerAccountCounterparty TELE. The trade is published as New with IsInternalTrade false.

Evidence: 4. 186 TradeEvent TELE.png, 5. 186 payload IsInternalTrade false.png

### AC 5. Amend event - **PASSED ✅**
The amend 21030788 of the internal ticket 21030768 is published as Amend with Glcs GBPESECM and IsInternalTrade true, and STP Hub acknowledges it.

Evidence: 6. 788 amend payload IsInternalTrade true.png, 7. 788 amend ack.png

### AC 14. End to end - **PASSED ✅**
21031187 goes from the TOMS event to the STP Hub payload with IsInternalTrade true and is acknowledged by STP Hub.

Evidence: 1. 187 TradeEvent GBPASECM.png, 2. 187 payload IsInternalTrade true.png, 3. 187 ack.png

---
**Pending:**
* AC 3: TOMS D2C trade received without validation. See question below.
* AC 6: cancel of an internal TOMS trade.
* AC 7: D2D trade.
* AC 8: allocation event with IsInternalTrade false. The Tradeweb allocation payload of 20261006.SAN3.EUGV.380 (Type ALLOC) has no IsInternalTrade field. Evidence: 9. 380 ALLOC payload sin IsInternalTrade.png
* AC 9: trading book lookup. The log of the lookup is not captured yet.

**Development scope:** AC 10 to AC 13 (unit tests).

@Fation Gjoni, AC 3: in which case is a TOMS D2C trade received without validation? For example, a ticket with CustomerAccountCounterparty empty? If yes, we will ask Sergio for that ticket.
