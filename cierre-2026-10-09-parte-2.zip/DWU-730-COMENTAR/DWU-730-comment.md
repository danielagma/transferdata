### **QA Update: scenarios 1, 2 and 6 PASSED ✅, scenarios 3, 4 and 5 PENDING**
* **Environment:** UAT2
* **Trades under test:** TOMS internal pair 21031187 (main) / 21031188 (mirror); TOMS internal amends 21030788 (main) / 21030791 (mirror) of the pair 21030768 / 21030769; TOMS manual ticket 21031186; TOMS amend 21030728 of Tradeweb 20261008.SAN3.EUGV.170

---
### Scenario 1. Internal trade, new (TT) - **PASSED ✅**
TOMS sends the main ticket 21031187 with SecondHalfTdr2TdrTrade N and the mirror ticket 21031188 with SecondHalfTdr2TdrTrade Y. The main is published as New with InternalTradeType Main and IsInternalTrade true, and STP Hub acknowledges it. For the mirror, Trade Service logs StpHubEventPublishingSkipped with Reason "The trade is an internal mirror" and IsInternalMirror true.

Evidence: 1-187-main-TradeEvent-SecondHalf-N.png, 2-188-mirror-TradeEvent-SecondHalf-Y.png, 3-187-main-payload.png, 4-187-main-ack.png, 5-188-mirror-StpHubEventPublishingSkipped.png

### Scenario 2. Amend of the internal trade (CTT) - **PASSED ✅**
TOMS sends SecondHalfTdr2TdrTrade Y on the mirror's amend 21030791 (TransactionType CTT, origin 21030769). The main amend 21030788 is published as Amend with InternalTradeType Main, and STP Hub acknowledges it. The mirror amend is not published.

Evidence: 6-791-mirror-amend-TradeEvent-SecondHalf-Y.png, 7-788-main-amend-payload.png, 8-788-main-amend-ack.png, 9-791-mirror-amend-no-results.png

### Scenario 6. Regression, non-internal trades - **PASSED ✅**
The TOMS manual ticket 21031186 is published as New with InternalTradeType Main and IsInternalTrade false. The TOMS amend 21030728 of 20261008.SAN3.EUGV.170 is published with InternalTradeType Main.

Evidence: 10-186-manual-New-payload.png, 11-TW170-amend-payload.png

---
**Pending:**
* Scenario 3: cancel of an internal trade.
* Scenario 4: internal futures ticket.
* Scenario 5: outbound replay of the mirror ticket.
