### **QA Update: Tradeweb butterfly with Darwin Calc'n OFF and TOMS ticket - PASSED ✅**
* **Environment:** UAT2
* **Trades under test:** Tradeweb butterfly 20261008.SAN3.EUGV.BFLY.53, legs 20261008.SAN3.EUGV.54 / .55 / .56, counterparty TELE, product class GILTS; TOMS manual ticket 21031186, counterparty TELE, product class EUROGOVIES

---
### AC 2. Tradeweb butterfly, Darwin Calc'n OFF - **PASSED ✅**
Darwin Calc'n is set to No on the TELE and GILTS row of Counterparty Relationship. The three legs are published with Glcs TELE, Instrument.Class GILTS and CalculateSalesCredit false. STP Hub acknowledges leg .54.

Evidence: 1-static-TELE-GILTS-Calcn-No.png, 2-leg54-payload.png, 3-leg54-ack.png, 4-leg55-payload.png, 5-leg56-payload.png

### AC 2. TOMS event - **PASSED ✅**
Darwin Calc'n is Yes on the TELE and EUROGOVIES row of Counterparty Relationship. The TOMS manual ticket 21031186 is published with Glcs TELE, Instrument.Class EUROGOVIES and CalculateSalesCredit true.

Evidence: 7-static-TELE-EUROGOVIES-Calcn-Yes.png, 6-toms-21031186-payload.png

---
**Pending:**
* AC 6: D2D trade.
* AC 7: confirmation from the STP Hub schema.

@Fation Gjoni could you confirm whether CalculateSalesCredit is listed in the required array of the STP Hub JSON schema (AC 7)?
