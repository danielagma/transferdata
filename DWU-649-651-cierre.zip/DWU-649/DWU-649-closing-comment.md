### **QA Execution: PASSED ✅**
* **Environment:** UAT2
* **Trade under test:** TOMS internal trade booked on 5 October, two halves: 21028997 (FO_BONOS buys from FO_DCORT) and 21028998 (FO_DCORT sells to FO_BONOS)

**Execution Summary:**
Both halves of the internal trade are published to STP Hub.

---
### 1. Both halves received - **PASSED ✅**
TradeEvent for 21028997 and for 21028998.

Evidence: 1-TradeEvent-both-halves.png

### 2. 21028997 published - **PASSED ✅**
StpHubPayloadSent at 14:07:01 UTC, IsInternalTrade: true, Counterparty.Glcs: FO_DCORT, Counterparty.Type: Bank.

Evidence: 2-payload-21028997.png

### 3. 21028998 published - **PASSED ✅**
StpHubPayloadSent at 14:07:02 UTC, IsInternalTrade: true, Counterparty.Glcs: FO_BONOS, Counterparty.Type: Bank.

Evidence: 3-payload-21028998.png

---
**Sign-off:** Approved to close.
