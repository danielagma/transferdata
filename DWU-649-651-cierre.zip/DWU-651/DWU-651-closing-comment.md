### **QA Execution: PASSED ✅**
* **Environment:** UAT2
* **Trade under test:** TOMS ticket 21028988, booked on 5 October with Mifid Transparency outside the standard list

**Execution Summary:**
TOMS sent Mifid Transparency "RPRI,TNCP". Darwin did not reject it, published it as sent, and STP Hub acknowledged it.

---
### 1. TOMS value outside the list - **PASSED ✅**
TradeEvent, TX669 MIFID_II_RPT_PST_TRADE_INDICATOR: RPRI,TNCP.

Evidence: 1-TradeEvent.png

### 2. Published as sent - **PASSED ✅**
StpHubPayloadSent at 13:46:16 UTC, Mifid.Transparency: ["RPRI","TNCP"].

Evidence: 2-payload.png

### 3. Accepted by STP Hub - **PASSED ✅**
StpHubPayloadAcknowledgedPublished at 13:46:16.663 UTC.

Evidence: 3-ack.png

---
**Sign-off:** Approved to close.
