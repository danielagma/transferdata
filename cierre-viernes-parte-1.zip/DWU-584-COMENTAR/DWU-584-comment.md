### **QA Update: AC 1, 2, 4, 5 and 14 PASSED ✅, AC 3, 6, 7, 8 and 9 PENDING, AC 10 to 13 development scope**
* **Environment:** UAT2
* **Trades under test:** TOMS internal ticket 21031187 (CustomerAccountCounterparty GBPASECM); TOMS manual ticket 21031186 (CustomerAccountCounterparty TELE); TOMS amend 21030788 of the internal ticket 21030768

---
### AC 1 and AC 4. New trade, counterparty matches an active trading book - **PASSED ✅**
TOMS sends 21031187 with CustomerAccountCounterparty GBPASECM, the trading book of its mirror ticket 21031188. The trade is published as New with IsInternalTrade true, and STP Hub acknowledges it.

Evidence: 1-187-TradeEvent-GBPASECM.png, 8-188-TradeEvent-TradingBook-GBPASECM.png, 2-187-payload-IsInternalTrade-true.png, 3-187-ack.png

### AC 2 and AC 4. New trade, counterparty does not match a trading book - **PASSED ✅**
TOMS sends 21031186 with CustomerAccountCounterparty TELE. The trade is published as New with IsInternalTrade false.

Evidence: 4-186-TradeEvent-TELE.png, 5-186-payload-IsInternalTrade-false.png

### AC 5. Amend event - **PASSED ✅**
The amend 21030788 of the internal ticket 21030768 is published as Amend with IsInternalTrade true, and STP Hub acknowledges it.

Evidence: 6-788-amend-payload-IsInternalTrade-true.png, 7-788-amend-ack.png

### AC 14. End to end - **PASSED ✅**
21031187 goes from the TOMS event to the STP Hub payload with IsInternalTrade true and is acknowledged by STP Hub.

Evidence: 1-187-TradeEvent-GBPASECM.png, 2-187-payload-IsInternalTrade-true.png, 3-187-ack.png

---
**Pending:**
* AC 6: cancel of an internal trade. Requested to Sergio.
* AC 7: D2D trade.
* AC 3, AC 8 and AC 9: see question below.

**Development scope:** AC 10 to AC 13 (unit tests).

@Fation Gjoni, for AC 3 (default false when no validation is performed), AC 8 (allocation events) and AC 9 (trading book lookup instead of GLCS), which trade or check would you like QA to use in UAT2?
