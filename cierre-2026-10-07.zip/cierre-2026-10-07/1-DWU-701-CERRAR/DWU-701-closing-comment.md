### **QA Execution: PASSED ✅**
* **Environment:** UAT2
* **Trades under test:** Tradeweb 20261007.SAN3.EUGV.1 (trader n317167), TOMS ticket 21030344, Tradeweb 20261007.SAN3.EUGV.86 (trader x531532, no Tradeweb code)

**Execution Summary:**
The reported Tradeweb case is fixed. ExecutionMktId and InvestmentMktId carry the trader code with type PERSON, and the trade is acknowledged by STP Hub. The TOMS case and the missing-code case were also verified.

---
### 1. Tradeweb trade with trader code (scenario 1) - **PASSED ✅**
TradeEvent at 06:52:01.187 UTC. StpHubPayloadSent at 06:52:03.649 UTC: ExecutionMktId n317167, ExecutionMktIdType PERSON, InvestmentMktId n317167, InvestmentMktIdType PERSON. StpHubPayloadAcknowledgedPublished at 06:52:04.920 UTC, MessageId 20261007.SAN3.EUGV.1:DWBZo7TjPDJqM4:New:0bff946bde081f03.

Evidence: 1-TW1-TradeEvent.png, 2-TW1-payload.png, 3-TW1-ack.png

### 2. TOMS trade with decision maker (scenario 3) - **PASSED ✅**
TradeEvent at 09:23:33.068 UTC, TX671 MIFID_II_DECISION_MAKER_WIN_FIRM n317167, TX672 MIFID_II_EXECUTION_WITHIN_FIRM n317167. StpHubPayloadDocument at 09:23:33.419 UTC: ExecutionMktId n317167, ExecutionMktIdType PERSON, InvestmentMktId n317167, InvestmentMktIdType PERSON. Acknowledged at 09:23:33.567 UTC, MessageId 21030344:DWBZo8B2x77Arg:New:6b966caa8f983242.

Evidence: 4-TOMS-TradeEvent-TX671-TX672.png, 5-TOMS-payload.png, 6-TOMS-ack.png

### 3. Trader without code (scenario 5) - **PASSED ✅**
StpHubPayloadDocument at 16:49:48.685 UTC: the four fields are null. StpHubMifidDataIncomplete at 16:49:48.585 UTC, level Error, MissingFields ExecutionMktId, ExecutionMktIdType, InvestmentMktId, InvestmentMktIdType. The trade is still published and acknowledged at 16:49:48.809 UTC, MessageId 20261007.SAN3.EUGV.86:DWBZoAEbZDE7Zg:New:b6843382249ee567.

Evidence: 7-TW86-payload-nulls.png, 8-TW86-StpHubMifidDataIncomplete.png, 9-TW86-ack.png

---
**Not verified in UAT2:** scenario 2 (Bloomberg or BondVision), scenario 4 (ORCA) and the Sentinel check of scenario 1. If they are needed, they can go in a separate ticket.

**Sign-off:** Approved to close for the reported Tradeweb case.
