### **QA Update: multi-leg with Darwin Calc'n OFF - PASSED ✅**
* **Environment:** UAT2
* **Trade under test:** Tradeweb switch 20261007.SAN3.EUGV.88 / 20261007.SAN3.EUGV.89, counterparty TELE, product class GILTS

Darwin Calc'n set to No on the TELE and GILTS row of Counterparty Relationship. Both legs are published with CalculateSalesCredit false, ComplexTradeId 20261007.SAN3.EUGV.SWAP.88, NumberOfLegs 2, RfqType MultiLeg, and both are acknowledged by STP Hub (leg 88 at 16:53:22.022 UTC, leg 89 at 16:53:22.330 UTC). Darwin Calc'n was set back to Yes after the trade.

Evidence: 1-static-TELE-GILTS-Calcn-No.png, 2-leg88-payload.png, 3-leg88-ack.png, 4-leg89-payload.png, 5-leg89-ack.png, 6-static-TELE-GILTS-Calcn-Yes-restored.png

AC 6 (D2D) stays blocked and AC 7 (JSON schema) still needs confirmation, as in the previous comment.
