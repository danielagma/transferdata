### **QA Execution: PASSED ✅**
* **Environment:** UAT2
* **Scope:** the case of this bug, where the allocation reaches STP Hub before its trade
* **Tradeweb (as reported):** switch 20261006.SAN3.EUGV.SWAP.380, 6 October, leg 20261006.SAN3.EUGV.380 allocated into two accounts
* **BondVision (same case on another venue):** trade MtsEUGVBondVision$11000111_20261006, 6 October, allocated into two accounts

**Execution Summary:**
On both venues the allocation was published first and the trade was still published and acknowledged. The "already sent" skip only stops a second publication of the same trade.

---
### 1. Tradeweb: allocation published first - **PASSED ✅**
StpHubPayloadSent at 16:59:24.629 UTC, PayloadType: StpHubPostTradeAllocationEvent, MessageId: TradewebEUGV$20261006.SAN3.EUGV.380:allocation:1045. Allocations: Test 1 80000.0, Test 2 20000.0. Acknowledged at 16:59:24.653 UTC.

Evidence: TW1-TradeEvent.png, TW2-allocation-payload.png, TW3-allocation-ack.png

### 2. Tradeweb: trade published after the allocation - **PASSED ✅**
StpHubEventPublishingSkipped at 16:59:24.725 UTC, Reason: "The STP Hub event was already sent", IsStpHubEventQueued: true.
StpHubPayloadSent at 16:59:24.779 UTC, PayloadType: StpHubPostTradeEvent, MessageId: 20261006.SAN3.EUGV.380:DWBZo3djakSzWD:New:ba3882ebc451609b, NumberOfLegs: 2. Acknowledged at 16:59:25.315 UTC.

Evidence: TW4-skipped.png, TW5-trade-payload.png, TW6-trade-ack.png

### 3. BondVision: allocation published first - **PASSED ✅**
StpHubPayloadSent at 10:40:29.151 UTC, PayloadType: StpHubPostTradeAllocationEvent, MessageId: MtsEUGVBondVision$11000111_20261006:allocation:3. Acknowledged at 10:40:29.237 UTC.

Evidence: BV1-allocation-payload.png, BV2-allocation-ack.png

### 4. BondVision: trade published after the allocation - **PASSED ✅**
StpHubPayloadSent at 10:40:29.221 UTC, PayloadType: StpHubPostTradeEvent, MessageId: 11000111_20261006:DWBZo1tQ4pWCwK:New:99b27bfa558eedf8. Acknowledged at 10:40:29.547 UTC.
StpHubEventPublishingSkipped at 10:40:29.435 UTC, after the trade was sent.

Evidence: BV3-trade-payload.png, BV4-trade-ack.png, BV5-skipped.png

---
**Sign-off:** Approved to close.
