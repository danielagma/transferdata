### **QA Execution: PASSED ✅**
* **Environment:** UAT2
* **Trader under test:** X531532, Bloomberg outbound mapping 5321 in Trader Platform Codes
* **Trades under test:** two Tradeweb outrights, 6 October, on GB00BNNGP668
* **Case A:** 20261006.SAN3.EUGV.378, with the Bloomberg row
* **Case B:** 20261006.SAN3.EUGV.379, with the Bloomberg row removed before the trade and added back after it

**Execution Summary:**
With the Bloomberg row, TraderUuid is the Bloomberg external code 5321. Without the Bloomberg row, TraderUuid is null, the payload is not published, and Trade Service logs TraderBloombergUuidMissing with the trader. The Darwin trader code is never published as TraderUuid.

---
### Case A. Trader with a Bloomberg row - **PASSED ✅**
TradeEvent at 16:46:41.312 UTC, TradeId: 20261006.SAN3.EUGV.378.
StpHubPayloadSent at 16:46:41.581 UTC, TraderId: x531532, User.TraderUuid: 5321.
StpHubPayloadAcknowledgedPublished at 16:46:41.770 UTC, MessageId: 20261006.SAN3.EUGV.378:DWBZo3a6COxZaK:New:5d9309889461e01f.

Evidence: A1-TradeEvent.png, A2-payload-TraderUuid-5321.png, A3-ack.png

### Case B. Trader without a Bloomberg row - **PASSED ✅**
TradeEvent at 16:52:10.793 UTC, TradeId: 20261006.SAN3.EUGV.379.
TraderBloombergUuidMissing (Error) at 16:52:10.928 UTC: TraderCode: x531532, ResolvedTraderCode: X531532, Reason: "The trader has no outbound Bloomberg platform mapping. The STP Hub payload will fail validation until reference data is fixed."
StpHubPayloadValidationFailed (Warning) at 16:52:10.974 UTC: field User.TraderUuid is invalid, value is null.
No StpHubPayloadSent and no acknowledgement for 20261006.SAN3.EUGV.379.

Evidence: B1-TradeEvent.png, B2-TraderBloombergUuidMissing.png, B3-StpHubPayloadValidationFailed.png, B4-no-payload.png, B5-no-ack.png

---
**Sign-off:** Approved to close.
