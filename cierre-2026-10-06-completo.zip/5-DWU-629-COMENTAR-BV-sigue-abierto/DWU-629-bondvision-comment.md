### **QA Execution: BondVision PASSED ✅ · Bug stays open**
* **Environment:** UAT2
* **Scope:** BondVision allocation ("The same applies to BondVision"). Bloomberg is pending: the bug was reported on Bloomberg.
* **Trade under test:** BondVision trade MtsEUGVBondVision$11000111_20261006, 6 October, allocated into two accounts

**Execution Summary:**
The BondVision allocation event publishes MarketCode with the venue value, the same value as the trade event. It does not publish a fixed value like "Bloomberg".

---
### 1. Allocation event MarketCode - **PASSED ✅**
StpHubPayloadSent at 10:40:29.151 UTC, PayloadType: StpHubPostTradeAllocationEvent, Type: ALLOC, MarketCode: MTS_BONDVISION.

Evidence: 1-payload-allocation-StpHubPayloadSent.png

### 2. Trade event MarketCode, same trade - **PASSED ✅**
StpHubPayloadSent at 10:40:29.221 UTC, PayloadType: StpHubPostTradeEvent, Type: TRADE, MarketCode: MTS_BONDVISION.

Evidence: 2-payload-trade-StpHubPayloadSent.png

### 3. Allocation acknowledged by STP Hub - **PASSED ✅**
StpHubPayloadAcknowledgedPublished at 10:40:29.237 UTC, MessageId: MtsEUGVBondVision$11000111_20261006:allocation:3.

Evidence: 3-ack-allocation.png

---
**Sign-off:** BondVision passes in UAT2. The bug is not closed: it needs a Bloomberg allocation where MarketCode is BLOOMBERG_MAP_POST_TRADE.
