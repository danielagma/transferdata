TOMS amend 21030209 is not published to STP Hub
Environment: UAT2, 6 October 2026. Times in UTC.

Trade: Tradeweb trade 20261006.SAN3.EUGV.60 (ES00000124C5, Sell), booked 16:28:20 and published to STP Hub as New.
Amendment: TOMS ticket 21030209, amend of TOMS ticket 21030023, done by Sergio.

Result: the amendment reaches Darwin, Trade Service fails with a null reference, and nothing is sent to STP Hub.

1-amend-arrives-TradeEvent-part1.png
   TradeEvent at 17:23:24.749. LifecycleAction: Amend, TransactionNumber: 21030209, OriginalTradeId: 21030023, TradeId: Tradeweb:20261006.SAN3.EUGV.60, SourceSystemName: Tradeweb. ContextId: C39Y1319100021030209.

2-amend-arrives-TradeEvent-part2.png
   Same TradeEvent, end of the TOMS XML (TradeFeedXml).

3-trade-service-flow-ContextId.png
   Search ContextId: "C39Y1319100021030209", 21 results. Trade Service logs InsertVenueTradeEventsFailed at 17:23:24.822, then VenueEventsHandlerFailed (Error) and RetriableMessageNotSuccessfullyHandled at 17:23:24.888. No ProcessCommand and no STP Hub log after that.

4-error-VenueEventsHandlerFailed.png
   The error opened. Reason: "Object reference not set to an instance of an object." TradeId: (null), RfqId: (null), SourceTradeId: empty, IsSuccess: false, IsRetry: false.

5-no-payload-StpHubPayloadSent.png
   Search Event.Type: "StpHubPayloadSent" and "21030209": No Results.

6-no-ack.png
   Search Event.Type: "StpHubPayloadAcknowledgedPublished" and "21030209": No Results.

7-tradeweb-60-only-New-payload.png
   StpHubPayloadSent of the Tradeweb trade 20261006.SAN3.EUGV.60 at 16:28:20.855: EventType New. This is the only payload for this trade. The amendment was not published under the Tradeweb id either.
