### **QA Execution: allocation before trade on BondVision PASSED ✅ · Bug stays open**
* **Environment:** UAT2
* **Scope:** the case of this bug (the allocation arrives before the trade), seen on BondVision. Tradeweb is pending: the bug was reported on a Tradeweb switch.
* **Trade under test:** BondVision trade MtsEUGVBondVision$11000111_20261006, 6 October, allocated into two accounts

**Execution Summary:**
The allocation reached STP Hub 70 ms before its trade. The trade was still published and acknowledged. The later "already sent" skip comes after the trade was sent, so it does not block it.

---
### 1. Allocation published first - **PASSED ✅**
StpHubPayloadSent at 10:40:29.151 UTC, PayloadType: StpHubPostTradeAllocationEvent, MessageId: MtsEUGVBondVision$11000111_20261006:allocation:3. Acknowledged at 10:40:29.237 UTC.

Evidence: 1-payload-allocation-StpHubPayloadSent.png, 3-ack-allocation.png

### 2. Trade published after the allocation - **PASSED ✅**
StpHubPayloadSent at 10:40:29.221 UTC, PayloadType: StpHubPostTradeEvent, MessageId: 11000111_20261006:DWBZo1tQ4pWCwK:New:99b27bfa558eedf8. Acknowledged at 10:40:29.547 UTC.

Evidence: 2-payload-trade-StpHubPayloadSent.png, 4-ack-trade.png

### 3. Duplicate publication skipped after the trade was sent - **PASSED ✅**
StpHubEventPublishingSkipped at 10:40:29.435 UTC, Reason: "The STP Hub event was already sent", IsStpHubEventQueued: true. This is 214 ms after the trade payload was sent.

Evidence: 5-StpHubEventPublishingSkipped.png

---
**Sign-off:** When the allocation arrives first, the trade is published and acknowledged on BondVision. The bug is not closed: it needs the retest on a Tradeweb switch with an allocation.
