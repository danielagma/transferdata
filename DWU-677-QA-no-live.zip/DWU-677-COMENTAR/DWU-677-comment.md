### **QA Update: non-Live mode in QA (RC-3217). Pre-check 2 PASSED ✅, check 1.1 New PASSED ✅, the rest PENDING**
* **Environment:** QA, RC-3217 deployed on 13 Oct
* **Trades under test:** Tradeweb RFQ trade 20261013.SAN3.EUGV.133 and the Tradeweb allocation of 20261013.SAN3.EUGV.95, both from the DWB QA regression on 13 Oct
* **Reference:** QA testing instructions in Murat's comment of 12 Oct

---
### Pre-check 2. StpHubRolloutSelected at startup with IsStpHubLive False - **PASSED ✅**
Seven services log StpHubRolloutSelected at startup on 13 Oct, all with IsStpHubLive false: Sentinel service, Trade service (two tasks), TransFicc PostTrade for Tradeweb, BondVision, Bloomberg BSGB and Bloomberg BSGI.

Evidence: 1-RolloutSelected-7-services.png, 2-RolloutSelected-SentinelService-false.png, 3-RolloutSelected-TradeService-1-false.png, 4-RolloutSelected-TradeService-2-false.png, 5-RolloutSelected-Tradeweb-PostTrade-false.png, 6-RolloutSelected-BondVision-PostTrade-false.png, 7-RolloutSelected-Bloomberg-BSGB-false.png, 8-RolloutSelected-Bloomberg-BSGI-false.png

### Check 1.1. RFQ trade, New - **PASSED ✅**
Trade 20261013.SAN3.EUGV.133 (Tradeweb RFQ, Sell 1,000,000 UKT 4.125 01/27, TELE):
* STP Hub: the payload is built (StpHubPayloadDocument) and not sent. StpHubPayloadSuppressed has the same MessageId and the reason "The gateway runs in ConnectivityOnly mode, so nothing is put on STP Hub."
* Sentinel: MessageSentToSentinel for the RFQ (Type Created) and for the trade (Type TradeAgreed, StatusStr TRADE_AGREED, Event INSERT).

Evidence: 9-133-StpHubPayloadDocument.png, 10-133-StpHubPayloadSuppressed-ConnectivityOnly.png, 11-133-MessageSentToSentinel-Created.png, 12-133-MessageSentToSentinel-TradeAgreed.png

The allocation of 20261013.SAN3.EUGV.95 (EventType Amend, StpHubPostTradeAllocationEvent) is also suppressed with the same reason.

Evidence: 13-95-allocation-Amend-StpHubPayloadSuppressed.png

---
**Pending:**
* Pre-check 3: no startup failure about StpHubRollout:IsLive.
* Check 1.1: amend and cancel of an RFQ trade, and no SentinelReportSuppressed for RFQ trades.
* Check 1.2: manual TOMS trade with no RFQ.
* Checks 1.3 and 1.4: Tradeweb sweep trades.
* Check 1.5: RFQ trade with an allocation that changes the reported counterparty.
* Check 1.6: covered by checks 1.1 to 1.5, counting the Sentinel messages per test trade.
* Check 3: STP Hub delivery failing or pending.

@Murat Guney, a few questions so we can run the pending checks in QA:
1. Pre-check 2: should StpHubRolloutSelected also appear for the TOMS inbound and the TransFicc Alloc services? We only see the seven above.
2. Checks 1.3 and 1.4: sweep trades in August were run by Tradeweb on request (DWU-441). Is the development evidence enough for Release 1, or should we ask Tradeweb for a sweep session in QA?
3. Check 1.5: can Allocation Reporting be switched on for a counterparty in QA, and can a migration table row be added for one of our Tradeweb allocation accounts (Test 1, Test 2 or Test 3)?
4. Check 3: who can stop the STP Hub Gateway or the pending-trade store in QA for this check?
