### **QA Execution: PASSED ✅**
* **Environment:** UAT2
* **Trade under test:** Bloomberg deal 3564:20261006:1:5, 6 October, cancelled from TOMS (ticket 21029164). STP Hub InternalTradeId of the cancel: DWBZo0yeCHH1CC

**Execution Summary:**
The cancel message sent to STP Hub carries the sales book (SalespersonName from TOMS) in SalesBook, not the Sales Login.

---
### 1. Cancel received from TOMS - **PASSED ✅**
TradeEvent at 07:21:51.811 UTC, LifecycleAction: Reversal, TransactionNumber: 21029164. In the TOMS XML: SalespersonName: AMICHEL, SalespersonLogin: IGUERRAOROZ4.

Evidence: 1-TradeEvent-cancel-part1.png, 1-TradeEvent-cancel-part2.png

### 2. Cancel published with the sales book - **PASSED ✅**
StpHubPayloadSent at 07:21:52.653 UTC, EventType: Cancel, SourceId: 21029164, SalesBook: AMICHEL.

Evidence: 2-payload-cancel-StpHubPayloadSent.png

### 3. Cancel acknowledged by STP Hub - **PASSED ✅**
StpHubPayloadAcknowledgedPublished at 07:21:53.075 UTC, same MessageId: 21029164:DWBZo0yeCHH1CC:Cancel:696b42c24451307e.

Evidence: 3-ack-cancel.png

### 4. New logs from the fix plan - **PASSED ✅**
StpHubTomsOverridesApplied at 07:21:52.481 UTC: CaptureType: RfqWorkflow, SourceSalesBookInfo: AMICHEL, SalesBook: AMICHEL.
PublishingStpHubGatewayCommand at 07:21:52.541 UTC: EventType: Cancel, SalesBook: AMICHEL, InternalTradeType: Mirror, TradeSrc: Voice.

Evidence: 4-StpHubTomsOverridesApplied.png, 5-PublishingStpHubGatewayCommand.png

---
**Sign-off:** Approved to close.
