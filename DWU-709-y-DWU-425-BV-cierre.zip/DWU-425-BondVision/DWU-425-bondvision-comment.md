### **QA Execution: BondVision PASSED ✅ · Story stays open**
* **Environment:** UAT2
* **Scope:** BondVision allocations. Bloomberg is pending.
* **Allocation under test:** BondVision trade MtsEUGVBondVision$11000111_20261006, 6 October, allocated into two accounts

**Execution Summary:**
Darwin received the allocation event from TransFicc, built the allocation payload, wrote it to log and published it to STP Hub. STP Hub acknowledged it.

---
### Scenario 1. One payload for the allocation event - **PASSED ✅**
StpHubPayloadSent at 10:40:29.151 UTC, PayloadType: StpHubPostTradeAllocationEvent. The call stack starts at TradeAllocationEvent from TransFicc.Gateway.InquiryPostTrade.Service.

### Scenario 2. Payload written to log - **PASSED ✅**
The full payload is in Event.Document, with SourceId: 11000111_20261006 and the AllocationId of each entry.

### Scenario 3. Allocation list - **PASSED ✅**

| AllocationId | FundBreakdown | Quantity | QuantityType |
|---|---|---|---|
| 800250 | Test1 | 1000000.0 | NOTIONAL |
| 800251 | Test2 | 1000000.0 | NOTIONAL |

Other fields: Type: ALLOC, EventType: New, Side: Sell, MarketCode: MTS_BONDVISION, Operation.Date: 2026-10-06, Operation.Time: 10:40:28.962.

Evidence for scenarios 1 to 3: 1-payload-allocation-StpHubPayloadSent.png

### Scenario 4. End to end, published to STP Hub - **PASSED ✅**
StpHubPayloadAcknowledgedPublished at 10:40:29.237 UTC, same MessageId: MtsEUGVBondVision$11000111_20261006:allocation:3.

Evidence: 2-ack-allocation-StpHubPayloadAcknowledgedPublished.png

---
**Sign-off:** Tradeweb (3 October) and BondVision allocations pass in UAT2. The story is not closed: Bloomberg is pending the DWU-629 retest (MarketCode must be BLOOMBERG_MAP_POST_TRADE).
